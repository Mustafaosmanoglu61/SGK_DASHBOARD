# SGK İşe Giriş Dashboard - Değişiklikler

## Yapılan Güncellemeler

### 1. ❌ Error Rate KPI'ı Kaldırıldı
- "Error Rate" kartı tamamen kaldırıldı
- Gereksiz tekrar olan metrik olduğu için çıkarıldı

### 2. ✅ FTE Tasarrufu KPI'ı Eklendi
- **Formül**: FTE = (Kazanılan Zaman) / (8 saat × 22 gün × 3600 sn)
- **Hesaplama**: 
  - Manuel Toplam Süre = İşlem Sayısı × 240 saniye (4 dakika)
  - RPA Toplam Süre = Gerçek işlem süreleri toplamı
  - Kazanılan Zaman = Manuel - RPA
  - FTE Tasarrufu = Kazanılan Zaman / Aylık Toplam Çalışma Süresi
- **Gösterim**: FTE değeri + hint olarak saat cinsinden tasarruf

### 3. ✅ Manuel Kazanılan Zaman KPI'ı Eklendi
- **Formül**: Kazanılan Zaman = (İşlem Sayısı × 240 sn) - (Toplam RPA Süresi)
- **Gösterim**: Saat cinsinden + hint olarak saniye cinsinden
- **Varsayım**: Manuel işlem süresi = 4 dakika (240 saniye)

### 4. ❌ Tüm Kayıtlar Tablosu Kaldırıldı
- HTML'den tablo section'ı kaldırıldı
- app.js'den renderTable() fonksiyonu kaldırıldı
- renderAll()'dan renderTable() çağrısı kaldırıldı

## Sabitler (app.js)

```javascript
const MANUAL_TIME_SECONDS = 240; // 4 dakika manuel işlem varsayımı

// FTE hesaplama sabitleri
const WORKING_HOURS_PER_DAY = 8;
const WORKING_DAYS_PER_MONTH = 22;
const SECONDS_PER_HOUR = 3600;
const TOTAL_WORKING_SECONDS_PER_MONTH = 176 * 3600; // 633,600 saniye
```

## KPI Kartları (Güncel)

1. Toplam Kayıt
2. Başarılı İşe Giriş Sayısı
3. Hatalı İşe Giriş
4. Başarı Oranı
5. Toplam Süre
6. Avg İşlem Süresi (sn)
7. Toplam Başarısız Süresi
8. Toplam Başarılı Süresi
9. Günlük Ort. İşe Giriş
10. **FTE Tasarrufu** (YENİ)
11. **Manuel Kazanılan Zaman** (YENİ)

## Dosya Yapısı

```
SGK_ISE_GIRIS/
├── index.html          (Güncellenmiş - tablo kaldırıldı, yeni KPI'lar eklendi)
├── src/
│   ├── app.js          (Güncellenmiş - FTE hesaplamaları eklendi)
│   ├── style.css       (Değişmedi)
│   └── data.json       (Değişmedi)
└── DEGISIKLIKLER.md    (Bu dosya)
```
