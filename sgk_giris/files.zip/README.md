# SGK İşe Giriş Dashboard

## 📊 Dashboard Özellikleri

Modern, responsive ve kullanıcı dostu SGK İşe Giriş RPA süreci dashboard'u.

### 🎯 KPI Metrikleri (11 Adet)

1. **Toplam Kayıt** - İşlenen toplam kayıt sayısı
2. **Başarılı İşe Giriş Sayısı** - COMPLETED statüsündeki kayıtlar
3. **Hatalı İşe Giriş** - ERROR statüsündeki kayıtlar
4. **Başarı Oranı** - Başarılı/Toplam yüzdesi
5. **Toplam Süre** - RPA'nın harcadığı toplam süre (saat)
6. **Avg İşlem Süresi** - Ortalama işlem süresi (saniye)
7. **Toplam Başarısız Süresi** - ERROR kayıtlarının toplam süresi
8. **Toplam Başarılı Süresi** - COMPLETED kayıtlarının toplam süresi
9. **Günlük Ort. İşe Giriş** - Seçilen tarih aralığına göre günlük ortalama
10. **FTE Tasarrufu** ⭐ - Full-Time Equivalent tasarrufu
11. **Manuel Kazanılan Zaman** ⭐ - Manuel vs RPA süre farkı

### 📈 Grafikler ve Görselleştirmeler

- **Günlük Trend** - Zaman serisi line chart (7/15/30/Tümü gösterimi)
- **İşlem Yoğunluğu** - Saatlik bar chart
- **Personel Dağılım Analizi** - Bubble grid chart (JSCharting)
- **Tarihlere Göre Hastane Giriş Değişimi** - Animasyonlu racing bar chart
- **Yoğun Hata Nedenleri** - Horizontal bar chart
- **Top 10 Hatalı İşyeri** - Pie chart
- **Top 10 Başarılı İşyeri** - Pie chart

### 🔍 Filtreler

- **Tarih Aralığı** - Flatpickr ile gelişmiş tarih seçici
- **İşyeri** - Dropdown filtre
- **Departman** - Dropdown filtre
- **Status** - COMPLETED/ERROR
- **Arama** - Genel metin arama

### 📥 Özellikler

- **CSV Dışa Aktar** - Filtrelenmiş veriyi CSV olarak indir
- **Responsive Tasarım** - Mobil uyumlu
- **Real-time Filtreleme** - Anında sonuç gösterimi
- **Temiz UI** - Modern, minimalist tasarım

## 🚀 Kullanım

1. `index.html` dosyasını bir web tarayıcıda açın
2. `src/data.json` dosyasının yolunu kontrol edin
3. Dashboard otomatik olarak yüklenecektir

## 📁 Dosya Yapısı

```
SGK_ISE_GIRIS/
├── index.html              # Ana HTML dosyası
├── src/
│   ├── app.js              # Dashboard logic
│   ├── style.css           # Stiller
│   └── data.json           # Veri dosyası
├── DEGISIKLIKLER.md        # Değişiklik listesi
└── README.md               # Bu dosya
```

## 🔧 Teknik Detaylar

### Sabitler

```javascript
MANUAL_TIME_SECONDS = 240            // 4 dakika manuel işlem varsayımı
WORKING_HOURS_PER_DAY = 8            // Günlük çalışma saati
WORKING_DAYS_PER_MONTH = 22          // Aylık çalışma günü
TOTAL_WORKING_SECONDS_PER_MONTH = 633,600  // 176 saat
```

### FTE Hesaplama Formülü

```
Manuel Toplam = İşlem Sayısı × 240 saniye
RPA Toplam = Gerçek işlem süreleri toplamı
Kazanılan Zaman = Manuel Toplam - RPA Toplam
FTE Tasarrufu = Kazanılan Zaman ÷ 633,600 saniye
```

### Manuel Tasarruf Hesaplama

```
Manuel Tasarruf = (İşlem Sayısı × 240 sn) - (Toplam RPA Süresi)
```

## 📦 Bağımlılıklar

- **Chart.js** - Bar/Pie chartlar için
- **JSCharting** - Bubble grid ve racing bar için
- **Flatpickr** - Tarih seçici için

## 🎨 Tasarım

- Light mode modern UI
- Soft shadows ve rounded corners
- Professional color palette
- Responsive grid layout

## 📝 Veri Formatı

JSON array formatında, her kayıt:

```json
{
  "tc_masked": "XXX***XX",
  "ad": "Ad",
  "soyad": "Soyad",
  "ise_giris_tarihi": "01/02/2023 00:00:00",
  "departman": "Departman Adı",
  "isyeri": "İşyeri",
  "pozisyon": "Pozisyon",
  "unvan": "Ünvan",
  "status": "COMPLETED|ERROR",
  "start_date": "2023-01-02T09:38:26",
  "end_date": "2023-01-02T09:38:53",
  "date_key": "2023-01-02",
  "duration_sec": 27,
  "error_comment": "...",
  ...
}
```

## ✅ Son Güncellemeler

- ❌ Error Rate KPI'ı kaldırıldı
- ✅ FTE Tasarrufu KPI'ı eklendi
- ✅ Manuel Kazanılan Zaman KPI'ı eklendi
- ❌ Kayıtlar tablosu kaldırıldı

Detaylı değişiklikler için `DEGISIKLIKLER.md` dosyasına bakınız.

---

**Geliştirme:** RPA Dashboard v2.0  
**Tarih:** Şubat 2026
